function showDetails(name, date, time, location, guest, price, desc) {
  document.querySelector(".details-section").style.display = "block";

  document.getElementById("dName").innerText = name;
  document.getElementById("dDate").innerText = date;
  document.getElementById("dTime").innerText = time;
  document.getElementById("dLocation").innerText = location;
  document.getElementById("dGuest").innerText = guest;
  document.getElementById("dPrice").innerText = price;
  document.getElementById("dDesc").innerText = desc;

  document.getElementById("details")
    .scrollIntoView({ behavior: "smooth" });
}

function enroll() {
  alert("Enrollment Successful!");
  return false;
}
